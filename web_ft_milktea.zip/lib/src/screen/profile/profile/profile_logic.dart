import 'package:get/get.dart';

class ProfileLogic extends GetxController {

}

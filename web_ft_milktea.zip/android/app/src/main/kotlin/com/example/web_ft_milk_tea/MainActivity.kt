package com.example.web_ft_milk_tea

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

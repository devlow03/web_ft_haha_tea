class GlobalData{
  GlobalData._();

  static const String domain = "http://hahatea.thiendev202.id.vn/";
  static const String tokenStore = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI0MzU2NDU2MCIsIm5hbWUiOiJ0aGllbmRldiIsImlhdCI6MTUxNjIzOTAyMn0.ZdpvmVDoRRxq2NGo-_3aX5g9vLwtDuLeXRYhgFDCPr0";
}
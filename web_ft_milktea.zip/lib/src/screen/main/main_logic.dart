import 'package:get/get.dart';

class MainLogic extends GetxController {
 Rxn<int>tabIndex = Rxn(0);
}
